"""
CryptoVault - Multi-Engine Command-Line Cryptographic Utility
Developed for the Spider Cybersecurity & DevOps Induction Assignment.

Features:
- Stage 1: Robust Caesar Shift Engine with Upper/Lower case wrapping rules.
- Stage 1 Cryptanalysis: Automated frequency profiling text cracker.
- Stage 2: Hash Guard SHA-256 data envelope integrity validation mechanism.
- Stage 3 Bonus: Industrial AES-256-CBC binary block cipher processing stream.
"""

import os
import sys
import argparse
import hashlib
import getpass  # Terminal layer masking for hidden password fields

# Advanced cryptography primitives from PyCa_Cryptography library
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives import hashes, padding


# ======================================================================
# STAGE 1 CORE ENGINE: ALPHABETIC CAESAR SHIFT TRANSFORMATIONS
# ======================================================================

def caesar_cipher_engine(text_data: str, shift_key: int, decrypt_mode: bool = False) -> str:
    """
    Shifts alphabetic characters by a set numeric shift value.
    Preserves case mappings and passes symbols, punctuation, and spaces unaltered.
    """
    # Reverse the transformation vector if the system specifies decryption
    if decrypt_mode:
        shift_key = -shift_key
        
    processed_characters = []
    
    for character in text_data:
        if character.isalpha():
            # Apply modulo arithmetic over 26 letters to prevent indexing out of bounds
            if character.islower():
                ascii_base = ord('a')
                shifted_char = chr((ord(character) - ascii_base + shift_key) % 26 + ascii_base)
                processed_characters.append(shifted_char)
            elif character.isupper():
                ascii_base = ord('A')
                shifted_char = chr((ord(character) - ascii_base + shift_key) % 26 + ascii_base)
                processed_characters.append(shifted_char)
        else:
            # Pass spaces, numbers, and special symbols through unchanged
            processed_characters.append(character)
            
    return "".join(processed_characters)


# ======================================================================
# STAGE 1 CRYPTANALYSIS: AUTOMATED LINGUISTIC FREQUENCY PROFILE CRACKER
# ======================================================================

def crack_caesar_cipher(ciphertext: str):
    
    """
    Brute-forces all 26 possible combinations and scores each alignment
    using standard English letter distribution frequency constants.
    """
    english_letter_frequencies = {
        'a': 0.0817, 'b': 0.0149, 'c': 0.0278, 'd': 0.0425, 'e': 0.1270, 
        'f': 0.0223, 'g': 0.0202, 'h': 0.0609, 'i': 0.0697, 'j': 0.0015, 
        'k': 0.0077, 'l': 0.0403, 'm': 0.0241, 'n': 0.0675, 'o': 0.0751, 
        'p': 0.0193, 'q': 0.0009, 'r': 0.0599, 's': 0.0633, 't': 0.0906, 
        'u': 0.0276, 'v': 0.0098, 'w': 0.0236, 'x': 0.0015, 'y': 0.0197, 'z': 0.0007
    }
    
    candidate_scores = []
    
    # Calculate fitness metrics for all 26 possible rotation offsets
    for candidate_shift in range(26):
        # We simulate decryption by passing decrypt_mode=True
        candidate_plaintext = caesar_cipher_engine(ciphertext, candidate_shift, decrypt_mode=True)
        
        current_score = 0.0
        for character in candidate_plaintext.lower():
            if character in english_letter_frequencies:
                current_score += english_letter_frequencies[character]
                
        candidate_scores.append((current_score, candidate_shift, candidate_plaintext))
        
    # Sort variants to pull the highest likelihood strings to the top
    candidate_scores.sort(key=lambda item: item[0], reverse=True)
    
    print("\n=== STAGE 1: AUTOMATED FREQUENCY ANALYSIS CRACK RESULTS ===")
    for index in range(min(3, len(candidate_scores))):
        score, shift, text = candidate_scores[index]
        print(f"Rank {index+1} (Linguistic Score: {score:.4f} | Discovered Shift Key: {shift}):")
        print(f"  Plaintext Output: \"{text}\"\n")


# ======================================================================
# STAGE 2: HASH GUARD PACKAGING AND PARITY VALIDATION ROUTINES
# ======================================================================

def compute_sha256_signature(text_content: str) -> str:
    """Generates a secure 64-character hex cryptographic hash of a text block."""
    return hashlib.sha256(text_content.encode('utf-8')).hexdigest()


# ======================================================================
# STAGE 3 BONUS: INDUSTRIAL-GRADE AES-256-CBC METRICS
# ======================================================================

def derive_aes_key(user_password: str, salt_bytes: bytes) -> bytes:
    """Uses PBKDF2 with SHA-256 to stretch a password into a 256-bit AES key."""
    key_derivation_handler = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,  # Target length matching symmetric key boundaries
        salt=salt_bytes,
        iterations=100000  # Hardens key derivation against GPU brute-force attacks
    )
    return key_derivation_handler.derive(user_password.encode('utf-8'))


def aes_symmetric_file_pipeline(target_path: str, password_string: str, decrypt_mode: bool = False):
    """
    Encrypts or decrypts ANY file structure treating raw inputs as pure binary bytes.
    Maintains security via dynamic salts, random IVs, and automated PKCS7 alignments.
    """
    try:
        if not os.path.exists(target_path):
            print(f"[-] Error: System file path '{target_path}' does not exist.")
            return

        # --------------------------------------------------------------
        # AES RUNTIME DECRYPTION
        # --------------------------------------------------------------
        if decrypt_mode:
            with open(target_path, "rb") as input_file:
                # Read structural markers sequentially from header space
                salt_bytes = input_file.read(16)
                iv_bytes = input_file.read(16)
                raw_encrypted_payload = input_file.read()

            # Reproduce the AES key pattern using the exact salt embedded in the file
            aes_key = derive_aes_key(password_string, salt_bytes)

            # Rebuild the decryption pipeline state
            cipher_handler = Cipher(algorithms.AES(aes_key), modes.CBC(iv_bytes))
            decryptor_engine = cipher_handler.decryptor()
            padded_plaintext_bytes = decryptor_engine.update(raw_encrypted_payload) + decryptor_engine.finalize()

            # Strip block alignment padding bytes cleanly via PKCS7 standard rules
            unpadder_engine = padding.PKCS7(128).unpadder()
            recovered_binary_data = unpadder_engine.update(padded_plaintext_bytes) + unpadder_engine.finalize()

            # Strip .aes suffix and tag output filename clearly
            output_destination = target_path.replace(".aes", "") + ".recovered"
            with open(output_destination, "wb") as output_file:
                output_file.write(recovered_binary_data)

            print(f"[▲] SUCCESS: AES decryption executed perfectly. Clean file generated: {output_destination}")

        # --------------------------------------------------------------
        # AES RUNTIME ENCRYPTION
        # --------------------------------------------------------------
        else:
            with open(target_path, "rb") as input_file:
                raw_plaintext_bytes = input_file.read()

            # Initialize cryptographic parameters
            salt_bytes = os.urandom(16)
            iv_bytes = os.urandom(16)

            # Derive the 256-bit AES key block
            aes_key = derive_aes_key(password_string, salt_bytes)

            # Enforce 16-byte block alignment boundaries using PKCS7 padding
            padder_engine = padding.PKCS7(128).padder()
            padded_plaintext_bytes = padder_engine.update(raw_plaintext_bytes) + padder_engine.finalize()

            # Execute symmetric encryption block calculations
            cipher_handler = Cipher(algorithms.AES(aes_key), modes.CBC(iv_bytes))
            encryptor_engine = cipher_handler.encryptor()
            encrypted_payload = encryptor_engine.update(padded_plaintext_bytes) + encryptor_engine.finalize()

            # Write compound array structure: SALT + IV + CIPHERTEXT
            output_destination = target_path + ".aes"
            with open(output_destination, "wb") as output_file:
                output_file.write(salt_bytes)
                output_file.write(iv_bytes)
                output_file.write(encrypted_payload)

            print(f"[+] SUCCESS: AES-256 military-grade protection applied. Output file stored: {output_destination}")

    except Exception as error_msg:
        print(f"[-] Critical failure during Advanced Cryptographic Processing Pipeline: {str(error_msg)}")


# ======================================================================
# MASTER CLI DISPATCH ROUTER INTERFACE
# ======================================================================

def handle_cryptovault_cli(args):
    """
    Coordinates data routing paths across Caesar, Hash Guard, and AES algorithms
    depending on flags supplied by the user at the command line.
    """
    try:
        # Check if the execution path requests AES processing mode
        if hasattr(args, 'mode') and args.mode == "aes":
            print(f"[*] Initializing Secure Vault Sub-Engine for target path: {args.file_path}")
            user_secret = getpass.getpass("[*] Enter Secure Master Password: ")
            if not user_secret:
                print("[-] Error: Password key cannot be empty.")
                return
            
            is_decryption = (args.command == "decrypt")
            aes_symmetric_file_pipeline(args.file_path, user_secret, decrypt_mode=is_decryption)
            return

        # Verification check for Caesar operations file targets
        if not os.path.exists(args.file_path):
            print(f"[-] Error: Target file '{args.file_path}' does not exist.")
            return

        # --------------------------------------------------------------
        # CAESAR ENCRYPTION PATHWAY
        # --------------------------------------------------------------
        if args.command == "encrypt":
            with open(args.file_path, "r", encoding="utf-8") as file_handle:
                raw_plaintext = file_handle.read()

            encrypted_payload = caesar_cipher_engine(raw_plaintext, args.shift, decrypt_mode=False)

            if args.verify:
                plaintext_hash = compute_sha256_signature(raw_plaintext)
                # Envelope structural format: HASH::CIPHERTEXT
                final_file_output = f"{plaintext_hash}::{encrypted_payload}"
                print("[+] Hash Guard: Integrity signature calculated and sealed inside envelope.")
            else:
                final_file_output = encrypted_payload

            output_filename = args.file_path + ".enc"
            with open(output_filename, "w", encoding="utf-8") as out_file:
                out_file.write(final_file_output)

            print(f"[+] Success: Encrypted file safely stored at: {output_filename}")

        # --------------------------------------------------------------
        # CAESAR DECRYPTION PATHWAY
        # --------------------------------------------------------------
        elif args.command == "decrypt":
            with open(args.file_path, "r", encoding="utf-8") as file_handle:
                file_contents = file_handle.read()

            # Parse envelope fields if a structural delimiter match is found
            if "::" in file_contents:
                stored_hash_signature, encrypted_payload = file_contents.split("::", 1)
                has_integrity_metadata = True
            else:
                encrypted_payload = file_contents
                has_integrity_metadata = False

            recovered_plaintext = caesar_cipher_engine(encrypted_payload, args.shift, decrypt_mode=True)

            # Evaluate hash signature match to detect tampering changes
            if has_integrity_metadata:
                print("[*] Hash Guard: Splicing integrity tags... analyzing payload...")
                current_calculated_hash = compute_sha256_signature(recovered_plaintext)
                
                if current_calculated_hash == stored_hash_signature:
                    print("[▲] INTEGRITY CHECK PASSED: Data file is pristine. Zero tampering detected.")
                else:
                    print("[▼] CRITICAL WARNING: TAMPERING DETECTED! Stored signature mismatch.")
                    print(f"    Expected Hash: {stored_hash_signature}")
                    print(f"    Computed Hash: {current_calculated_hash}")
            elif args.verify and not has_integrity_metadata:
                print("[-] Warning: Verification flag requested but file has no embedded signature.")

            # If the file ends with .enc, strip it out cleanly, otherwise append .dec
            if args.file_path.endswith(".enc"):
                output_filename = args.file_path[:-4] + ".dec"
            else:
                output_filename = args.file_path + ".dec"
                
            with open(output_filename, "w", encoding="utf-8") as out_file:
                out_file.write(recovered_plaintext)

            print(f"[+] Success: Decrypted content written out cleanly to: {output_filename}")

    except Exception as error_msg:
        print(f"[-] Critical system fault during processing pipeline: {str(error_msg)}")


# ======================================================================
# CORE SUBCOMMAND BOOTSTRAP REGISTER
# ======================================================================
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="CryptoVault - Enterprise Command-Line Security Utility")
    subparsers = parser.add_subparsers(dest="command", required=True)

    # Subcommand registration mapping for encryption execution routes
    encrypt_parser = subparsers.add_parser("encrypt", help="Secure encryption processing layer")
    encrypt_parser.add_argument("file_path", help="Target input file path")
    encrypt_parser.add_argument("--shift", type=int, default=3, help="Caesar numeric shift metric (Defaults to 3)")
    encrypt_parser.add_argument("--verify", action="store_true", help="Embed SHA-256 internal hash verification tags")
    encrypt_parser.add_argument("--mode", choices=["caesar", "aes"], default="caesar", help="Engine selection ('caesar' or 'aes')")

    # Subcommand registration mapping for decryption execution routes
    decrypt_parser = subparsers.add_parser("decrypt", help="Secure decryption processing layer")
    decrypt_parser.add_argument("file_path", help="Target input file path")
    decrypt_parser.add_argument("--shift", type=int, default=3, help="Caesar numeric shift metric (Defaults to 3)")
    decrypt_parser.add_argument("--verify", action="store_true", help="Execute SHA-256 parity verification checks")
    decrypt_parser.add_argument("--mode", choices=["caesar", "aes"], default="caesar", help="Engine selection ('caesar' or 'aes')")

    # Subcommand registration mapping for brute-force tracking routines
    crack_parser = subparsers.add_parser("crack", help="Automated linguistic cracking via frequency analytics")
    crack_parser.add_argument("ciphertext_string", help="Ciphertext payload block bounded in quotes")

    args = parser.parse_args()
    
    if args.command in ["encrypt", "decrypt"]:
        handle_cryptovault_cli(args)
    elif args.command == "crack":
        crack_caesar_cipher(args.ciphertext_string)

