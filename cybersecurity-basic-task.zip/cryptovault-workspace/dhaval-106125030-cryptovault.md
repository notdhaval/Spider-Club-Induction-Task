# CryptoVault - Multi-Engine Cryptographic CLI Tool

CryptoVault is a command-line utility built for file encryption, decryption, automated text analysis, and data integrity verification. It supports basic alphabetic transformations, structural signature checking, and password-based symmetric file protection.

This tool was developed as part of the Spider Cybersecurity & DevOps induction assignment.

---

## Features

### 1. Alphabetic Shift Engine (Stage 1)
* Implements a basic Caesar cipher that handles full uppercase (A-Z) and lowercase (a-z) character boundaries.
* Leaves whitespace, numbers, punctuation marks, and special symbols completely unaltered to preserve the original formatting.

### 2. Frequency Analysis Text Cracker (Stage 1 Cryptanalysis)
* Automatically evaluates an encrypted text string against a standard frequency mapping of the English language.
* Brute-forces all 26 possible rotation combinations simultaneously and displays the top 3 choices with the highest linguistic probability.

### 3. Hash Guard Data Integrity (Stage 2)
* Protects encrypted text files against unauthorized changes using SHA-256 validation.
* Seals the data in a specific envelope format: `[SHA-256 Hash]::[Ciphertext Payload]`.
* Automatically parses the hash during decryption and alerts the user if the file content has been altered or corrupted.

### 4. Symmetric AES-256 Block Cipher (Stage 3 Bonus)
* Processes target files as raw binary bytes, making it capable of locking text documents, images, PDFs, or binary files.
* Uses industry-standard AES-256-CBC encryption.
* Integrates PBKDF2 with SHA-256 running 100,000 iterations to turn standard human passwords into secure cryptographic keys.
* Ensures proper 16-byte cryptographic block alignments using PKCS7 padding profiles.

---

## Usage Guide

### Caesar Shift and Integrity Checks (Stage 1 & 2)

#### To encrypt a file using a shift key and add an integrity signature:
* bash code:
* python cryptovault.py encrypt data.txt --shift 7 --verify

*This generates a file named data.txt.enc.

#### To decrypt a signature-sealed file and check if it has been tampered with:
* bash code:
* python cryptovault.py decrypt data.txt.enc --shift 7 --verify

* This generates a decrypted file named data.dec (stripping out the original .enc extension automatically if present).

### Automated Cryptanalysis (Stage 1 Cracking)

#### To run the frequency analyzer over a short snippet of intercepted ciphertext without knowing the key:
* bash code:
* python cryptovault.py crack "vszzc pfc"

### AES-256 Symmetric Protection (Stage 3 Bonus)

#### To encrypt any file type securely using a master password:

* bash code:
* python cryptovault.py encrypt document.pdf --mode aes

* The command line will securely hide your keystrokes while you type the password. This generates a file named document.pdf.aes.

#### To decrypt an AES file and recover your original data:

* bash code:
* python cryptovault.py decrypt document.pdf.aes --mode aes
* This generates a recovered file named document.pdf.recovered

## Technical Stack & Dependencies
### Language Support: Python 3.x
### Standard Modules Used: os, sys, argparse, hashlib, getpass
### External Framework Core: cryptography (PyCa)
